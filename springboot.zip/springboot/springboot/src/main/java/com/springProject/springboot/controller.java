package com.springProject.springboot;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.fop.apps.FOPException;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.xml.transform.TransformerException;
import java.io.File;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Base64;


@Component
@RestController

@CrossOrigin(origins = "http://localhost:4200/")

public  class controller {
    //@Autowired
    //private FOPPdfDemo FOPPdfDemo;
    //private final System.Logger log = (System.Logger) LoggerFactory.getLogger( this.getClass( ) );
    //@Resource
    //FOPPdfDemo FOPPdfDemo;


    @PostMapping(value = "saveUploadFiles")
    public UploadFiles saveUploadFiles(@RequestParam("file") MultipartFile[] file, @RequestParam("data") String data) throws IOException, FOPException, TransformerException {

        UploadFiles responseDto = new UploadFiles();



        /*
        //fileUploadService.uploadFile(file[3]);
        String filename = file[3].getOriginalFilename();

        String encoded = Base64.getEncoder().encodeToString(file[3].getBytes());

        //UploadFiles responseDto = new UploadFiles(filename,encoded);
        //System.out.println(responseDto);
        //return responseDto;
*/
        String a = new String(file[0].getOriginalFilename());

        // String b=a.substring(0,3);
        System.out.println(a);
        File f = new File(a);
        String absolute = f.getAbsolutePath();
        System.out.println(absolute);

        String b = new String(file[1].getOriginalFilename());

        // String b=a.substring(0,3);
        System.out.println(b);
        File f1 = new File(b);
        String absolute1 = f1.getAbsolutePath();
        System.out.println(absolute1);


        String value = new String();
        System.out.println(data);

        if (data.contains("PDF")) {
            value = "PDF";
        } else if (data.contains("TXT")) {
            value = "TXT";
        } else if (data.contains("RTF")) {
            value = "RTF";
        } else if (data.contains("PS")) {
            value = "PS";
        } else if (data.contains("PRINT")) {
            value = "PRINT";
        }


        switch (value) {
            case "PDF": {
                //pdf = "success";
                System.out.println("PDF is going to generate");
                FOPPdfDemo FOPPdfDemo = new FOPPdfDemo();
                OutputStream outputpdf= FOPPdfDemo.convertToPDF();

                //File output = new File("C:\\Users\\ANARMADH\\Downloads\\demo\\src\\main\\resources\\pdfcreation\\output1.pdf");
                File output = new File(outputpdf.toString());
// fopPdfConversion.convertToFO();

                String filename = output.getName();


                String encoded = Base64.getEncoder().encodeToString(output.getName().getBytes());
                System.out.println(encoded);

                responseDto = new UploadFiles(filename,encoded);
                break;
                // @Resource
                // FOPPdfDemo FOPPdfDemo = new FOPPdfDemo();
                //String result;
                // FOPPdfDemo.convertToPDF(absolute,absolute1);



              /* File output = new String(pathname:"");


                String filename = output.getBytes();


                String encoded = Base64.getEncoder().encodeToString(filename);
                System.out.println(encoded);

                responseDto = new UploadFiles(filename,encoded);

                return responseDto;*/

            }
            case "TXT": {
                //pdf = "txt";
                System.out.println("TXT is going to generate");
                //FOPTxtConversion fopTxtDemo = new FOPTxtConversion();
                //fopTxtDemo.convertToTXT();
                break;
            }
            case "RTF": {
                // pdf = "RTF";
                System.out.println("RTF is going to generate");
                //FOPRtfConversion fopRtfDemo = new FOPRtfConversion();
                //fopRtfDemo.convertToRTF();
                break;
            }
            case "PS": {
                //pdf = "PS";
                System.out.println("POSTSCRIPT");
                break;
            }
            case "PRINT": {
                //pdf = "PRINT";
                System.out.println("PRINT");
                break;
            }
            default: {
                System.out.println("Choose the valid option");
            }
        }


        return responseDto;



  /*  @GetMapping("/")
    public String greet() {

        return "welcome to the application";

    }*/

        //return null;
    }

}

