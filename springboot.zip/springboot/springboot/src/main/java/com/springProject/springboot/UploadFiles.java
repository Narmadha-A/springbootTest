package com.springProject.springboot;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.web.multipart.MultipartFile;


import java.io.Serializable;
import java.util.Date;
@JsonIgnoreProperties
//@Entity
//@Table(name = "uploadFiles")
public class UploadFiles {
    private String fileName;
    private String Content;

    public UploadFiles() {

    }

    public UploadFiles(String fileName, String content) {
        this.fileName = fileName;
        this.Content = content;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }

    @Override
    public String toString() {
        return "ResponseDto{" +
                "fileName='" + fileName + '\'' +
                ", Content='" + Content + '\'' +
                '}';
    }

}
